// swift-tools-version: 6.1
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
  name: "AdtalosSDK",
  platforms: [.iOS(.v12), .macOS(.v10_15)],
  products: [
    // Products define the executables and libraries a package produces, making them visible to other packages.
    .library(
      name: "AdtalosSDK",
      targets: ["AdtalosSDK"]
    )
  ],
  dependencies: [
  ],
  targets: [
	.binaryTarget(
      name: "SwiftPackageManagerTest",
      url: "https://example.com/AdtalosSDK.xcframework.zip",
      checksum: "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
    ),
  ]
)
